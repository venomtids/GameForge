import { humanoid, animateHumanoid } from "./Humanoid";
import { PhysicalRig } from "./PhysicalRig";
import { BotController } from "./BotController";
import {
  advancedGeometry,
  configureAdvancedBody,
  pixelTexture,
} from "./surfaces";
import { AudioEngine } from "./Audio";
import { Environment } from "./Environment";
import {
  mergeLight,
  torchDefaults,
  type LightSettings,
  type TorchSettings,
} from "./features07";
import { VoxelVolume } from "./VoxelVolume";
import { makeNode, kindNames, behaviorNames } from "./model";
import { actorDefaults, validateActor } from "./features06";
import type { UIElement } from "./studio-model";
import * as THREE from "three";
import * as CANNON from "cannon-es";
import { controls, Node3D, SceneData, Project } from "./model";

export function geometry(kind: Node3D["kind"]): THREE.BufferGeometry {
  if (kind === "sphere") return new THREE.SphereGeometry(0.5, 24, 16);
  if (kind === "cylinder") return new THREE.CylinderGeometry(0.5, 0.5, 1, 12);
  if (kind === "cone") return new THREE.ConeGeometry(0.5, 1, 8);
  return new THREE.BoxGeometry(1, 1, 1);
}
export function disposeTree(root: THREE.Object3D) {
  root.traverse((o) => {
    if (o instanceof THREE.Mesh || o instanceof THREE.LineSegments) {
      o.geometry.dispose();
      const mats = Array.isArray(o.material) ? o.material : [o.material];
      mats.forEach((m) => {
        if (m instanceof THREE.MeshStandardMaterial) m.map?.dispose();
        m.dispose();
      });
    }
  });
  root.removeFromParent();
}
export class World {
  motions = new Map<string, { x: number; z: number; speed: number }>();
  turns = new Map<string, number>();
  physicalRigs = new Map<string, PhysicalRig>();
  health = new Map<string, number>();
  botOrigins = new Map<string, THREE.Vector3>();
  bots = new BotController();
  lights = new Map<string, THREE.PointLight | THREE.SpotLight>();
  flickers = new Map<string, { until: number; amount: number }>();
  tweens: {
    id: string;
    from: Record<string, number>;
    to: Record<string, number>;
    colorFrom: THREE.Color | null;
    colorTo: THREE.Color | null;
    t: number;
    dur: number;
  }[] = [];
  /** objeto na mao livre do jogador (view model) */
  hand: { kind: string; ate: number } = { kind: "nenhum", ate: 0 };
  /** tremor de camera pedido por script */
  shake: { amount: number; until: number } = { amount: 0, until: -1 };
  torch: TorchSettings = {
    ...torchDefaults,
    offset: [...torchDefaults.offset] as [number, number, number],
  };
  audio = new AudioEngine();
  root = new THREE.Group();
  environment: Environment | null = null;
  voxels: VoxelVolume | null = null;
  ui: UIElement[] = [];
  uiPatches = new Map<string, Record<string, unknown>>();
  events: string[] = [];
  sceneId = "";
  inputFrozen = false;
  settings: Project["settings"] = { background: "#202a30", gravity: -9.81 };
  objects = new Map<string, THREE.Object3D>();
  bodies = new Map<string, CANNON.Body>();
  physics: CANNON.World | null = null;
  configs: Node3D[] = [];
  options = controls({});
  private accumulator = 0;
  private lastJump = -100;
  private jumpQueuedUntil = -100;
  elapsed = 0;
  collected = 0;
  total = 0;
  playing = false;
  deaths = 0;
  completed = false;
  checkpointIndex = -1;
  checkpointName = "Início";
  spawn = new THREE.Vector3();
  private lastGround = -100;
  private lastWarning = -100;
  playerId: string | null = null;
  hidden = new Set<string>();
  active = new Set<string>();
  onEvent: (text: string) => void = () => {};
  constructor(public scene: THREE.Scene) {
    scene.add(this.root);
  }
  load(data: SceneData, settings: Project["settings"], playing = false) {
    this.clear();
    this.playing = playing;
    this.options = controls(settings);
    this.configs = structuredClone(data.nodes);
    this.settings = settings;
    this.torch = {
      ...torchDefaults,
      ...(settings.torch ?? {}),
      offset: [
        ...(settings.torch?.offset ?? torchDefaults.offset),
      ] as [number, number, number],
    };
    this.audio.setVolume(settings.volume ?? 0.9);
    this.sceneId = data.id;
    this.ui = structuredClone(data.ui ?? []);
    if (settings.sky?.enabled)
      this.environment = new Environment(this.scene, settings.sky);
    if (data.voxel) {
      this.voxels = new VoxelVolume(data.voxel, settings.textures ?? []);
      this.root.add(this.voxels.group);
    }
    this.scene.background = new THREE.Color(settings.background);
    for (const n of data.nodes) {
      this.health.set(n.id, n.actor.health);
      const obj = n.actor.humanoid
        ? humanoid(n)
        : n.kind === "group"
          ? new THREE.Group()
          : new THREE.Mesh(
              n.behavior === "collectible"
                ? new THREE.OctahedronGeometry(0.5)
                : (advancedGeometry(n) ?? geometry(n.kind)),
              new THREE.MeshStandardMaterial({
                color:
                  n.kind === "terrain" || n.textureId ? "#ffffff" : n.color,
                vertexColors: n.kind === "terrain",
                map: this.textureFor(n.textureId, n.scale),
                transparent: !!n.textureId,
                alphaTest: n.textureId ? 0.1 : 0,
                roughness: n.roughness,
                metalness: n.metalness,
                flatShading: n.kind === "cone",
                emissive: n.behavior === "collectible" ? n.color : "#000000",
                emissiveIntensity: n.behavior === "collectible" ? 0.25 : 0,
              }),
            );
      obj.name = n.name;
      obj.userData.nodeId = n.id;
      obj.position.fromArray(n.position);
      obj.rotation.set(
        ...(n.rotation.map(THREE.MathUtils.degToRad) as [
          number,
          number,
          number,
        ]),
      );
      obj.scale.fromArray(n.scale);
      obj.visible = n.visible;
      obj.castShadow = n.castShadow;
      obj.receiveShadow = n.receiveShadow;
      this.objects.set(n.id, obj);
      if (n.light.type !== "none") this.createLight(n, obj);
    }
    for (const n of data.nodes)
      (this.objects.get(n.parent ?? "") ?? this.root).add(
        this.objects.get(n.id)!,
      );
    this.root.updateMatrixWorld(true);
    if (!playing) return;
    for (const n of data.nodes)
      if (n.actor.bot !== "off")
        this.botOrigins.set(
          n.id,
          this.objects.get(n.id)!.getWorldPosition(new THREE.Vector3()),
        );
    this.physics = new CANNON.World({
      gravity: new CANNON.Vec3(0, settings.gravity, 0),
    });
    this.physics.broadphase = new CANNON.SAPBroadphase(this.physics);
    (this.physics.solver as CANNON.GSSolver).iterations = Math.round(
      this.options.solverIterations,
    );
    (this.physics.solver as CANNON.GSSolver).tolerance = 1e-7;
    this.physics.allowSleep = true;
    this.physics.defaultContactMaterial.friction = 0.3;
    const preferred = data.nodes.find(
      (n) => n.id === settings.playerId && n.behavior === "player" && n.visible,
    );
    for (const n of data.nodes) {
      const o = this.objects.get(n.id)!;
      let visible = true;
      o.traverseAncestors((a) => {
        if (!a.visible) visible = false;
      });
      if (!n.visible || !visible) continue;
      this.active.add(n.id);
      if (n.behavior === "collectible") this.total++;
      if (
        n.behavior === "player" &&
        !this.playerId &&
        (!preferred || n.id === preferred.id)
      ) {
        this.playerId = n.id;
        this.spawn.copy(o.getWorldPosition(new THREE.Vector3()));
      }
      this.addBody(n);
    }
    for (const n of data.nodes)
      if (n.deform.type !== "none") this.activateRig(n.id, n.deform.type);
  }
  /** Cria (ou recria) o corpo físico de um nó conforme physics/mass/friction/restitution. */
  addBody(n: Node3D) {
    if (!this.physics || n.physics === "none" || n.kind === "group") return null;
    if (["collectible", "checkpoint", "finish", "hazard"].includes(n.behavior))
      return null;
    const o = this.objects.get(n.id);
    if (!o) return null;
    const current = this.bodies.get(n.id);
    if (current) this.physics.removeBody(current);
    const p = o.getWorldPosition(new THREE.Vector3()),
      q = o.getWorldQuaternion(new THREE.Quaternion()),
      s = o.getWorldScale(new THREE.Vector3());
    const shape =
      n.kind === "sphere"
        ? new CANNON.Sphere(Math.max(s.x, s.y, s.z) * 0.5)
        : n.kind === "cylinder" || n.kind === "cone"
          ? new CANNON.Cylinder(
              n.kind === "cone" ? 0 : Math.max(s.x, s.z) * 0.5,
              Math.max(s.x, s.z) * 0.5,
              s.y,
              n.kind === "cone" ? 8 : 12,
            )
          : new CANNON.Box(new CANNON.Vec3(s.x * 0.5, s.y * 0.5, s.z * 0.5));
    const body = new CANNON.Body({
      mass: n.physics === "dynamic" ? n.mass : 0,
      shape,
      position: new CANNON.Vec3(p.x, p.y, p.z),
      quaternion: new CANNON.Quaternion(q.x, q.y, q.z, q.w),
      material: new CANNON.Material({
        friction:
          n.behavior === "player" || n.actor.bot !== "off" ? 0 : n.friction,
        restitution: n.restitution,
      }),
      fixedRotation: n.behavior === "player" || n.actor.bot !== "off",
      allowSleep: n.behavior !== "player" && n.actor.bot === "off",
      linearDamping: n.behavior === "player" ? 0 : 0.01,
    });
    configureAdvancedBody(body, n, s, q);
    body.updateMassProperties();
    this.bodies.set(n.id, body);
    this.physics.addBody(body);
    return body;
  }
  private dropBody(id: string) {
    const body = this.bodies.get(id);
    if (body) this.physics?.removeBody(body);
    this.bodies.delete(id);
  }
  createLight(n: Node3D, o: THREE.Object3D) {
    if (n.light.type === "none") return null;
    const s = n.light,
      light =
        s.type === "spot"
          ? new THREE.SpotLight(
              s.color,
              s.intensity,
              s.distance,
              THREE.MathUtils.degToRad(s.angle),
              s.penumbra,
              s.decay,
            )
          : new THREE.PointLight(
              s.color,
              s.intensity,
              s.distance,
              s.decay,
            );
    light.name = "node-light";
    light.userData.nodeId = n.id;
    if (light instanceof THREE.SpotLight) {
      light.target.position.set(0, -1, 0);
      light.add(light.target);
      light.target.updateMatrixWorld();
    }
    this.syncLight(light, s);
    o.add(light);
    this.lights.set(n.id, light);
    return light;
  }
  /** Textura do nó com repetição calculada pelo tamanho da peça (1 tile = textureTile m). */
  textureFor(textureId: string | null | undefined, scale: number[]) {
    if (!textureId) return null;
    const t = this.settings.textures?.find((x) => x.id === textureId);
    if (!t) return null;
    const tex = pixelTexture(t);
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;
    this.applyTextureRepeat(tex, scale);
    return tex;
  }
  applyTextureRepeat(tex: THREE.Texture, scale: number[]) {
    const tile = this.settings.textureTile ?? 1.5;
    const dims = scale.map((v) => Math.abs(v)).sort((a, b) => b - a);
    tex.repeat.set(
      Math.max(1, Math.round((dims[0] ?? tile) / tile)),
      Math.max(1, Math.round((dims[1] ?? tile) / tile)),
    );
  }
  private syncLight(
    light: THREE.PointLight | THREE.SpotLight,
    s: LightSettings,
  ) {
    light.visible = s.enabled;
    light.color.set(s.color);
    light.intensity = s.intensity;
    light.distance = s.distance;
    light.decay = s.decay;
    if (light instanceof THREE.SpotLight) {
      light.angle = THREE.MathUtils.degToRad(s.angle);
      light.penumbra = s.penumbra;
    }
    if (light.castShadow !== s.shadows) {
      light.castShadow = s.shadows;
      if (s.shadows) {
        const size = light instanceof THREE.SpotLight ? 1024 : 512;
        light.shadow.mapSize.set(size, size);
        light.shadow.camera.near = 0.2;
        light.shadow.camera.far = Math.max(4, s.distance);
        light.shadow.bias = -0.0015;
        light.shadow.normalBias = 0.03;
        light.shadow.map?.dispose();
        light.shadow.map = null;
      }
    }
  }
  disposeLight(id: string) {
    const light = this.lights.get(id);
    if (!light) return;
    light.shadow?.map?.dispose();
    light.removeFromParent();
    this.lights.delete(id);
  }
  /** Aplica um patch parcial de luz (comando engine.light ou painel Inspetor). */
  applyLight(id: string, patch: any) {
    const n = this.configs.find((c) => c.id === id),
      o = this.objects.get(id);
    if (!n || !o || !patch || typeof patch !== "object") return;
    const merged = mergeLight(n.light, patch),
      typeChanged = merged.type !== n.light.type;
    n.light = merged;
    if (typeChanged || (merged.type !== "none" && !this.lights.has(id))) {
      this.disposeLight(id);
      if (merged.type !== "none") this.createLight(n, o);
    }
    const light = this.lights.get(id);
    if (light) this.syncLight(light, merged);
  }
  flicker(id: string, duration: number, amount: number) {
    if (!Number.isFinite(duration) || !Number.isFinite(amount)) return;
    const entry = {
      until: this.elapsed + THREE.MathUtils.clamp(duration, 0, 60),
      amount: THREE.MathUtils.clamp(amount, 0.05, 1),
    };
    if (id === "*" || !this.lights.has(id))
      for (const key of this.lights.keys()) this.flickers.set(key, entry);
    else this.flickers.set(id, entry);
  }
  torchCommand(patch: any, enabled?: boolean) {
    const clamp = (v: unknown, min: number, max: number, old: number) =>
      typeof v === "number" && Number.isFinite(v)
        ? THREE.MathUtils.clamp(v, min, max)
        : old;
    const p = patch && typeof patch === "object" ? patch : {};
    this.torch = {
      enabled:
        typeof enabled === "boolean"
          ? enabled
          : typeof p.enabled === "boolean"
            ? p.enabled
            : this.torch.enabled,
      color:
        typeof p.color === "string" && /^#[0-9a-f]{6}$/i.test(p.color)
          ? p.color
          : this.torch.color,
      intensity: clamp(p.intensity, 0, 60, this.torch.intensity),
      distance: clamp(p.distance, 0.5, 120, this.torch.distance),
      angle: clamp(p.angle, 5, 90, this.torch.angle),
      penumbra: clamp(p.penumbra, 0, 1, this.torch.penumbra),
      shadows:
        typeof p.shadows === "boolean" ? p.shadows : this.torch.shadows,
      offset: this.torch.offset,
    };
  }
  /** Tween genérico de transformação/luz resolvido pela engine (suave a 60 quadros). */
  move(id: string, patch: any, seconds: number) {
    const n = this.configs.find((c) => c.id === id),
      o = this.objects.get(id);
    if (!n || !o || !patch || typeof patch !== "object") return;
    const duration = Number.isFinite(seconds)
      ? THREE.MathUtils.clamp(seconds, 0.05, 60)
      : 0.4;
    const from: Record<string, number> = {},
      to: Record<string, number> = {};
    const read = (key: string) => {
      if (key === "x" || key === "y" || key === "z") return o.position[key] as number;
      if (key === "rx" || key === "ry" || key === "rz")
        return THREE.MathUtils.radToDeg(o.rotation[key[1] as "x" | "y" | "z"]);
      if (key === "sx" || key === "sy" || key === "sz")
        return o.scale[key[1] as "x" | "y" | "z"];
      return n.light.intensity;
    };
    for (const key of [
      "x",
      "y",
      "z",
      "rx",
      "ry",
      "rz",
      "sx",
      "sy",
      "sz",
      "intensity",
    ]) {
      const value = patch[key];
      if (typeof value !== "number" || !Number.isFinite(value)) continue;
      const limit = ["x", "y", "z"].includes(key)
        ? 2000
        : key === "intensity"
          ? 60
          : key.startsWith("s")
            ? 200
            : 3600;
      to[key] = THREE.MathUtils.clamp(value, -limit, limit);
      from[key] = read(key);
    }
    const colorTo =
      typeof patch.color === "string" && /^#[0-9a-f]{6}$/i.test(patch.color)
        ? new THREE.Color(patch.color)
        : null;
    const colorFrom =
      colorTo && o instanceof THREE.Mesh
        ? (o.material as THREE.MeshStandardMaterial).color.clone()
        : null;
    if (!Object.keys(to).length && !colorTo) {
      this.applyNodePatch(id, patch);
      return;
    }
    this.tweens = this.tweens.filter((t) => t.id !== id);
    this.tweens.push({
      id,
      from,
      to,
      colorFrom,
      colorTo,
      t: 0,
      dur: duration,
    });
  }
  private advanceTweens(dt: number) {
    if (!this.tweens.length) return;
    for (const tween of [...this.tweens]) {
      tween.t += Math.min(dt, 0.1);
      const k = Math.min(1, tween.t / tween.dur),
        e = k * k * (3 - 2 * k),
        patch: Record<string, unknown> = {};
      for (const [key, value] of Object.entries(tween.to))
        patch[key] = tween.from[key] + (value - tween.from[key]) * e;
      if (tween.colorFrom && tween.colorTo)
        patch.color =
          "#" + tween.colorFrom.clone().lerp(tween.colorTo, e).getHexString();
      this.applyNodePatch(tween.id, patch, { tweens: true });
      if (k >= 1) this.tweens.splice(this.tweens.indexOf(tween), 1);
    }
  }
  private lightingTick() {
    const t = this.elapsed;
    for (const [id, light] of this.lights) {
      const n = this.configs.find((c) => c.id === id);
      if (!n) continue;
      const event = this.flickers.get(id);
      let amount = Number.isFinite(n.light.flicker) ? n.light.flicker : 0,
        speed = Number.isFinite(n.light.flickerSpeed) ? n.light.flickerSpeed : 6;
      if (!Number.isFinite(n.light.intensity)) n.light.intensity = 0;
      if (event && t <= event.until) {
        amount = Math.max(amount, event.amount);
        speed = Math.max(speed, 18);
      } else if (event) this.flickers.delete(id);
      if (amount <= 0) {
        if (light.intensity !== n.light.intensity)
          light.intensity = n.light.intensity;
        if (light.visible !== n.light.enabled) light.visible = n.light.enabled;
        continue;
      }
      const noise =
        0.5 + 0.5 * Math.sin(t * speed * 7.3) * Math.sin(t * speed * 3.1);
      light.intensity =
        n.light.intensity * Math.max(0.05, 1 - amount * noise * 0.98);
      if (amount > 0.35 && Math.random() < amount * 0.12) light.visible = false;
      else light.visible = n.light.enabled;
    }
  }
  /** Patch validado de nó usado por engine.set, engine.spawn, tweens e testes. */
  applyNodePatch(
    id: string,
    patch: any,
    options: { tweens?: boolean } = {},
  ) {
    const o = this.objects.get(id),
      n = this.configs.find((c) => c.id === id);
    if (!o || !n || !patch || typeof patch !== "object") return;
    if (!options.tweens && this.physicalRigs.has(id)) return;
    const num = (v: unknown, min: number, max: number) =>
      typeof v === "number" && Number.isFinite(v)
        ? THREE.MathUtils.clamp(v, min, max)
        : undefined;
    let moved = false;
    for (const key of ["x", "y", "z"] as const) {
      const value = num(patch[key], -2000, 2000);
      if (value !== undefined) {
        o.position[key] = value;
        moved = true;
      }
    }
    for (const key of ["rx", "ry", "rz"] as const) {
      const value = num(patch[key], -3600, 3600);
      if (value !== undefined) {
        o.rotation[key[1] as "x" | "y" | "z"] = THREE.MathUtils.degToRad(value);
        moved = true;
      }
    }
    const scalePatch =
      Array.isArray(patch.scale) && patch.scale.length === 3
        ? patch.scale
        : ["sx", "sy", "sz"].every((k) => typeof patch[k] === "number")
          ? [patch.sx, patch.sy, patch.sz]
          : null;
    if (scalePatch) {
      const values = (scalePatch as unknown[]).map((v) => num(v, 0.02, 200));
      if (values.every((v) => v !== undefined)) {
        (values as number[]).forEach((v, i) => {
          o.scale.setComponent(i, v);
          n.scale[i] = v;
        });
        if (o instanceof THREE.Mesh) {
          const map = (o.material as THREE.MeshStandardMaterial).map;
          if (map) this.applyTextureRepeat(map, n.scale);
        }
        moved = true;
      }
    }
    if (o instanceof THREE.Mesh) {
      const material = o.material as THREE.MeshStandardMaterial;
      if (
        typeof patch.color === "string" &&
        /^#[0-9a-f]{6}$/i.test(patch.color)
      )
        material.color.set(patch.color);
      for (const key of ["roughness", "metalness"] as const) {
        const value = num(patch[key], 0, 1);
        if (value !== undefined) material[key] = value;
      }
      /* faces e luzes pintadas: brilho proprio (imagem que corta a escuridao) */
      if (
        typeof patch.emissive === "string" &&
        /^#[0-9a-f]{6}$/i.test(patch.emissive)
      ) {
        material.emissive.set(patch.emissive);
        if (!(material.emissiveIntensity > 0)) material.emissiveIntensity = 1;
      }
      if (typeof patch.emissiveIntensity === "number") {
        const value = num(patch.emissiveIntensity, 0, 6);
        if (value !== undefined) material.emissiveIntensity = value;
      }
      if (typeof patch.textureId === "string" || patch.textureId === null) {
        const map = this.textureFor(patch.textureId, n.scale);
        if (map || patch.textureId === null) {
          n.textureId = patch.textureId;
          material.map = map;
          material.color.set(map ? "#ffffff" : n.color);
          material.transparent = !!map;
          material.alphaTest = map ? 0.1 : 0;
          material.needsUpdate = true;
        }
      }
    }
    for (const key of ["visible", "castShadow", "receiveShadow"] as const)
      if (typeof patch[key] === "boolean") o[key] = patch[key];
    for (const key of ["speed", "amplitude"] as const) {
      const value = num(patch[key], 0, 100);
      if (value !== undefined) n[key] = value;
    }
    if (patch.actor && typeof patch.actor === "object") {
      const next = { ...n.actor };
      for (const key of Object.keys(next) as (keyof typeof next)[])
        if (
          typeof patch.actor[key] === typeof next[key] ||
          (typeof next[key] === "string" && typeof patch.actor[key] === "string")
        )
          (next as any)[key] = patch.actor[key];
      n.actor = validateActor(next);
      if (this.bodies.has(id) && n.physics === "dynamic")
        this.bodies.get(id)!.updateMassProperties();
    }
    if (
      typeof patch.behavior === "string" &&
      Object.keys(behaviorNames).includes(patch.behavior)
    )
      n.behavior = patch.behavior;
    if (patch.light && typeof patch.light === "object")
      this.applyLight(id, patch.light);
    const body = this.bodies.get(id);
    if (body) {
      for (const axis of ["x", "y", "z"] as const) {
        const value = num(patch["v" + axis], -100, 100);
        if (value !== undefined) body.velocity[axis] = value;
      }
      const physicsChanged =
        typeof patch.physics === "string" &&
        ["none", "static", "dynamic"].includes(patch.physics) &&
        patch.physics !== n.physics;
      if (physicsChanged) n.physics = patch.physics;
      for (const key of ["mass", "friction", "restitution"] as const) {
        const value = num(
          patch[key],
          key === "mass" ? 0.01 : 0,
          key === "mass" ? 10000 : 1,
        );
        if (value === undefined) continue;
        n[key] = value;
        if (physicsChanged || !body) continue;
        if (key === "mass") {
          body.mass = value;
          body.updateMassProperties();
        } else if (body.material)
          (body.material as CANNON.Material)[key] = value;
      }
      if (
        typeof patch.fixedRotation === "boolean" &&
        body.fixedRotation !== patch.fixedRotation
      ) {
        body.fixedRotation = patch.fixedRotation;
        body.updateMassProperties();
      }
      if (physicsChanged || (n.physics === "none" && this.bodies.has(id))) {
        this.normalizeBody(n);
      } else if (moved) {
        this.syncBody(id);
      } else {
        body.wakeUp();
      }
    } else if (
      typeof patch.physics === "string" &&
      ["static", "dynamic"].includes(patch.physics)
    ) {
      n.physics = patch.physics;
      this.addBody(n);
    }
    if (moved) o.updateMatrixWorld(true);
  }
  private normalizeBody(n: Node3D) {
    if (n.physics === "none") this.dropBody(n.id);
    else this.addBody(n);
  }
  private syncBody(id: string) {
    const body = this.bodies.get(id),
      o = this.objects.get(id);
    if (!body || !o) return;
    o.updateWorldMatrix(true, false);
    const p = o.getWorldPosition(new THREE.Vector3()),
      q = o.getWorldQuaternion(new THREE.Quaternion());
    body.position.set(p.x, p.y, p.z);
    body.quaternion.set(q.x, q.y, q.z, q.w);
    body.aabbNeedsUpdate = true;
    body.wakeUp();
  }
  grounded(body: CANNON.Body) {
    return (
      this.physics?.contacts.some(
        (c) =>
          c.enabled &&
          ((c.bi === body && c.ni.y < -0.5) || (c.bj === body && c.ni.y > 0.5)),
      ) ?? false
    );
  }
  damage(id: string, amount: number, source = "script") {
    if (!Number.isFinite(amount) || amount < 0) return;
    const n = this.configs.find((n) => n.id === id);
    if (!n) return;
    const old = this.health.get(id) ?? n.actor.health,
      next = Math.max(0, old - Math.min(100, amount));
    this.health.set(id, next);
    if (old > 0 && next === 0) {
      this.onEvent(n.name + " ficou sem vida (" + source + ").");
      if (n.actor.humanoid && n.actor.ragdollOnDeath)
        this.activateRig(id, "ragdoll");
    }
  }
  heal(id: string, amount: number) {
    if (!Number.isFinite(amount) || amount <= 0) return;
    const n = this.configs.find((c) => c.id === id);
    if (!n) return;
    const old = this.health.get(id) ?? n.actor.health;
    this.health.set(
      id,
      Math.min(n.actor.health, old + Math.min(100, amount)),
    );
  }
  activateRig(id: string, type: "ragdoll" | "jelly") {
    if (!this.physics || this.physicalRigs.has(id)) return;
    if (this.physicalRigs.size >= 12) {
      this.onEvent("Limite: 12 rigs físicos por cena.");
      return;
    }
    const n = this.configs.find((n) => n.id === id),
      o = this.objects.get(id);
    if (!n || !o || n.kind === "terrain" || n.kind === "group") return;
    const rig = new PhysicalRig(
      n,
      o,
      this.physics,
      this.root,
      type,
      this.bodies.get(id),
    );
    this.physicalRigs.set(id, rig);
    this.bodies.set(id, rig.anchor);
  }
  restoreRig(id: string) {
    const rig = this.physicalRigs.get(id);
    if (!rig) return;
    const pos = rig.object.getWorldPosition(new THREE.Vector3());
    rig.dispose(true);
    if (rig.original) {
      rig.original.position.set(pos.x, pos.y + rig.node.scale[1] * 0.4, pos.z);
      rig.original.velocity.setZero();
      rig.original.angularVelocity.setZero();
      rig.original.aabbNeedsUpdate = true;
      rig.original.wakeUp();
      this.bodies.set(id, rig.original);
    } else this.bodies.delete(id);
    this.physicalRigs.delete(id);
  }
  respawn() {
    if (this.playerId) {
      this.restoreRig(this.playerId);
      const n = this.configs.find((n) => n.id === this.playerId);
      if (n) this.health.set(n.id, n.actor.health);
    }
    const body = this.playerId ? this.bodies.get(this.playerId) : null;
    if (!body) return;
    body.position.set(this.spawn.x, this.spawn.y, this.spawn.z);
    body.velocity.setZero();
    body.angularVelocity.setZero();
    body.wakeUp();
    this.jumpQueuedUntil = -100;
    this.deaths++;
    this.lastGround = -100;
    this.onEvent(
      `Retornando a ${this.checkpointName}. Tentativas: ${this.deaths + 1}`,
    );
  }
  update(dt: number, keys: Set<string>, yaw = 0) {
    if (!Number.isFinite(dt) || dt <= 0) return;
    this.advanceTweens(dt);
    this.lightingTick();
    if (!this.playing || !this.physics || this.completed) return;
    this.accumulator += Math.min(dt, 0.1);
    const step =
      1 /
      (this.physicalRigs.size
        ? Math.max(120, this.options.physicsHz)
        : this.options.physicsHz);
    while (this.accumulator + 1e-10 >= step && !this.completed) {
      this.accumulator -= step;
      this.stepFixed(step, keys, yaw);
    }
  }
  private stepFixed(dt: number, keys: Set<string>, yaw: number) {
    if (!this.physics) return;
    this.elapsed += dt;
    let player = this.playerId ? this.bodies.get(this.playerId) : null;
    if (player && this.voxels)
      this.voxels.syncColliders(this.physics, player.position);
    if (this.inputFrozen) keys = new Set();
    if (keys.has("r") && this.playerId) {
      keys.delete("r");
      this.respawn();
      player = this.bodies.get(this.playerId)!;
    }
    if (
      player &&
      !this.physicalRigs.has(this.playerId!) &&
      (this.health.get(this.playerId!) ?? 100) > 0
    ) {
      const config = this.configs.find((n) => n.id === this.playerId)!;
      const dx =
        Number(keys.has("d") || keys.has("arrowright")) -
        Number(keys.has("a") || keys.has("arrowleft"));
      const dz =
        Number(keys.has("s") || keys.has("arrowdown")) -
        Number(keys.has("w") || keys.has("arrowup"));
      const length = Math.hypot(dx, dz) || 1;
      const speed =
        config.speed *
        this.options.moveMultiplier *
        (keys.has("shift") ? this.options.sprintMultiplier : 1);
      player.velocity.x =
        ((dx * Math.cos(yaw) + dz * Math.sin(yaw)) / length) * speed;
      player.velocity.z =
        ((-dx * Math.sin(yaw) + dz * Math.cos(yaw)) / length) * speed;
      if (this.grounded(player) && this.elapsed - this.lastJump > 0.12)
        this.lastGround = this.elapsed;
      if (keys.has("r")) {
        keys.delete("r");
        this.respawn();
      }
      if (dx || dz || keys.has(" ")) player.wakeUp();
      if (keys.has(" ")) {
        this.jumpQueuedUntil = this.elapsed + 0.12;
        keys.delete(" ");
      }
      if (
        this.jumpQueuedUntil >= this.elapsed &&
        this.elapsed - this.lastGround < 0.1
      ) {
        this.jumpQueuedUntil = -100;
        this.lastGround = -100;
        this.lastJump = this.elapsed;
        player.velocity.y = this.options.jumpSpeed;
        keys.delete(" ");
      }
      if (player.position.y < -18) this.respawn();
    }

    this.bots.update(this, dt);
    for (const [id, m] of this.motions) {
      if (this.physicalRigs.has(id) || (this.health.get(id) ?? 100) <= 0)
        continue;
      const b = this.bodies.get(id),
        o = this.objects.get(id);
      if (b && b.mass) {
        b.velocity.x = m.x * m.speed;
        b.velocity.z = m.z * m.speed;
        b.wakeUp();
      } else if (o) {
        o.position.x += m.x * m.speed * dt;
        o.position.z += m.z * m.speed * dt;
        if (b) {
          o.updateWorldMatrix(true, false);
          const pos = o.getWorldPosition(new THREE.Vector3());
          b.position.set(pos.x, pos.y, pos.z);
          b.aabbNeedsUpdate = true;
        }
      }
    }

    for (const rig of this.physicalRigs.values()) rig.beforeStep(dt);
    this.physics.step(dt);
    for (const rig of this.physicalRigs.values()) rig.sync();
    // Copy world-space physics transforms back into the local scene hierarchy.
    for (const n of this.configs) {
      const o = this.objects.get(n.id)!,
        b = this.bodies.get(n.id);
      if (this.physicalRigs.has(n.id)) continue;
      if (b && b.mass > 0) {
        const p = new THREE.Vector3(b.position.x, b.position.y, b.position.z);
        const q = new THREE.Quaternion(
          b.quaternion.x,
          b.quaternion.y,
          b.quaternion.z,
          b.quaternion.w,
        );
        if (o.parent) {
          o.parent.updateWorldMatrix(true, false);
          o.parent.worldToLocal(p);
          q.premultiply(
            o.parent.getWorldQuaternion(new THREE.Quaternion()).invert(),
          );
        }
        o.position.copy(p);
        o.quaternion.copy(q);
      } else if (!b) {
        if (n.behavior === "rotate")
          o.rotation.y =
            THREE.MathUtils.degToRad(n.rotation[1]) + this.elapsed * n.speed;
        if (n.behavior === "float")
          o.position.y =
            n.position[1] + Math.sin(this.elapsed * n.speed) * n.amplitude;
      }
      const turn = this.turns.get(n.id);
      if (turn) {
        o.rotation.y += THREE.MathUtils.degToRad(turn) * dt;
        if (b) {
          b.quaternion.set(
            o.quaternion.x,
            o.quaternion.y,
            o.quaternion.z,
            o.quaternion.w,
          );
          b.aabbNeedsUpdate = true;
          b.wakeUp();
        }
      }
      if (n.actor.humanoid)
        animateHumanoid(
          o,
          n,
          dt,
          b?.velocity.x ?? 0,
          b?.velocity.z ?? 0,
          b ? this.grounded(b) : true,
          b?.velocity.y ?? 0,
        );
      if (
        n.behavior === "collectible" &&
        this.active.has(n.id) &&
        !this.hidden.has(n.id) &&
        o.visible
      ) {
        o.rotation.y = this.elapsed * 1.5;
        o.position.y =
          n.position[1] + Math.sin(this.elapsed * 2 + n.position[0]) * 0.12;
        if (
          player &&
          o
            .getWorldPosition(new THREE.Vector3())
            .distanceTo(
              new THREE.Vector3(
                player.position.x,
                player.position.y,
                player.position.z,
              ),
            ) < 1
        ) {
          o.visible = false;
          this.hidden.add(n.id);
          this.collected++;
          this.onEvent(`Cristal coletado • ${this.collected}/${this.total}`);
          if (this.collected === this.total) {
            if (!this.configs.some((c) => c.behavior === "finish"))
              this.completed = true;
            this.onEvent(
              this.completed
                ? "Todos os cristais coletados! Cena concluída."
                : "Todos os cristais coletados! Alcance a chegada.",
            );
          }
        }
      }
    }
    if (player) {
      const p = new THREE.Vector3(
        player.position.x,
        player.position.y,
        player.position.z,
      );
      let index = -1;
      for (const n of this.configs) {
        if (n.behavior === "checkpoint") index++;
        if (
          !["checkpoint", "finish", "hazard"].includes(n.behavior) ||
          !this.active.has(n.id)
        )
          continue;
        const o = this.objects.get(n.id)!;
        const q = o.getWorldPosition(new THREE.Vector3());
        const near =
          Math.hypot(p.x - q.x, p.z - q.z) <
            Math.max(1.2, Math.min(n.scale[0], n.scale[2]) * 0.5) &&
          Math.abs(p.y - q.y) < 2;
        if (
          n.behavior === "checkpoint" &&
          near &&
          index > this.checkpointIndex &&
          this.grounded(player)
        ) {
          this.checkpointIndex = index;
          this.checkpointName = n.name;
          this.spawn.set(q.x, q.y + 1.3, q.z);
          this.onEvent(`${n.name} ativado!`);
        }
        if (
          n.behavior === "hazard" &&
          new THREE.Box3()
            .setFromObject(o)
            .expandByVector(new THREE.Vector3(0.3, 0.8, 0.3))
            .containsPoint(p)
        )
          this.respawn();
        if (n.behavior === "finish" && near && this.grounded(player)) {
          if (this.collected === this.total) {
            this.completed = true;
            player.velocity.setZero();
            this.onEvent(
              `Percurso concluído em ${this.elapsed.toFixed(1)} s • ${this.deaths} quedas.`,
            );
          } else if (this.elapsed - this.lastWarning > 3) {
            this.lastWarning = this.elapsed;
            this.onEvent(
              `Faltam ${this.total - this.collected} cristais para concluir.`,
            );
          }
        }
      }
    }
  }
  applyScript(id: string, state: any) {
    if (this.physicalRigs.has(id)) return;
    const o = this.objects.get(id);
    if (!o || !state || typeof state !== "object") return;
    const num = (key: string, old: number) =>
      typeof state[key] === "number" && Number.isFinite(state[key])
        ? THREE.MathUtils.clamp(state[key], -10000, 10000)
        : old;
    o.position.set(
      num("x", o.position.x),
      num("y", o.position.y),
      num("z", o.position.z),
    );
    o.rotation.set(
      THREE.MathUtils.degToRad(
        num("rx", THREE.MathUtils.radToDeg(o.rotation.x)),
      ),
      THREE.MathUtils.degToRad(
        num("ry", THREE.MathUtils.radToDeg(o.rotation.y)),
      ),
      THREE.MathUtils.degToRad(
        num("rz", THREE.MathUtils.radToDeg(o.rotation.z)),
      ),
    );
    if (typeof state.visible === "boolean") o.visible = state.visible;
    if (
      o instanceof THREE.Mesh &&
      typeof state.color === "string" &&
      /^#[0-9a-fA-F]{6}$/.test(state.color)
    )
      (o.material as THREE.MeshStandardMaterial).color.set(state.color);
    const b = this.bodies.get(id);
    if (b) {
      for (const axis of ["x", "y", "z"] as const) {
        const value = state["v" + axis];
        if (typeof value === "number" && Number.isFinite(value))
          b.velocity[axis] = THREE.MathUtils.clamp(value, -100, 100);
      }
      if (
        ["x", "y", "z", "rx", "ry", "rz"].some(
          (k) => typeof state[k] === "number",
        )
      ) {
        o.updateWorldMatrix(true, false);
        const p = o.getWorldPosition(new THREE.Vector3()),
          q = o.getWorldQuaternion(new THREE.Quaternion());
        b.position.set(p.x, p.y, p.z);
        b.quaternion.set(q.x, q.y, q.z, q.w);
        b.aabbNeedsUpdate = true;
      }
      b.wakeUp();
    }
  }
  command(c: any) {
    if (!c || typeof c.type !== "string") return;
    if (
      c.type === "walk" &&
      typeof c.id === "string" &&
      this.objects.has(c.id) &&
      [c.x, c.z, c.speed].every(
        (v) => typeof v === "number" && Number.isFinite(v),
      ) &&
      Math.abs(c.x) <= 1000 &&
      Math.abs(c.z) <= 1000 &&
      c.speed >= 0 &&
      c.speed <= 30
    ) {
      const length = Math.hypot(c.x, c.z) || 1;
      this.motions.set(c.id, {
        x: c.x / length,
        z: c.z / length,
        speed: c.speed,
      });
      const n = this.configs.find((n) => n.id === c.id);
      if (n) n.actor.bot = "off";
    }
    if (
      c.type === "rotate" &&
      typeof c.id === "string" &&
      this.objects.has(c.id) &&
      typeof c.speed === "number" &&
      Number.isFinite(c.speed) &&
      Math.abs(c.speed) <= 720
    )
      this.turns.set(c.id, c.speed);
    if (c.type === "stop" && typeof c.id === "string") {
      this.motions.delete(c.id);
      this.turns.delete(c.id);
      const b = this.bodies.get(c.id);
      if (b) {
        b.velocity.x = 0;
        b.velocity.z = 0;
      }
      const n = this.configs.find((n) => n.id === c.id);
      if (n) n.actor.bot = "off";
    }
    if (c.type === "hand" && typeof c.kind === "string")
      this.hand = {
        kind: c.kind.slice(0, 24),
        ate: this.elapsed + (Number.isFinite(c.seconds) ? c.seconds : 0),
      };
    if (c.type === "shake" && Number.isFinite(c.amount))
      this.shake = {
        amount: Math.max(0, Math.min(3, c.amount)),
        until:
          this.elapsed +
          Math.max(
            0.05,
            Math.min(10, Number.isFinite(c.seconds) ? c.seconds : 0.4),
          ),
      };
    if (c.type === "damage" && typeof c.id === "string")
      this.damage(c.id, c.amount);
    if (c.type === "heal" && typeof c.id === "string")
      this.heal(c.id, c.amount);
    if (c.type === "ragdoll" && typeof c.id === "string") {
      if (c.enabled === false) this.restoreRig(c.id);
      else this.activateRig(c.id, "ragdoll");
    }
    if (
      c.type === "impulse" &&
      typeof c.id === "string" &&
      [c.x, c.y, c.z].every(
        (v) =>
          typeof v === "number" && Number.isFinite(v) && Math.abs(v) <= 100,
      )
    ) {
      const rig = this.physicalRigs.get(c.id);
      if (rig) rig.impulse(c.x, c.y, c.z);
      else this.bodies.get(c.id)?.applyImpulse(new CANNON.Vec3(c.x, c.y, c.z));
    }
    if (
      c.type === "bot" &&
      typeof c.id === "string" &&
      ["off", "patrol", "follow", "attack"].includes(c.mode)
    ) {
      const n = this.configs.find((n) => n.id === c.id);
      if (n && n.id !== this.playerId) {
        const body = this.bodies.get(n.id);
        if (c.mode !== "off" && (!body || body.mass <= 0)) return;
        if (body && c.mode !== "off") {
          body.fixedRotation = true;
          body.allowSleep = false;
          body.angularVelocity.setZero();
          body.updateMassProperties();
          body.wakeUp();
        }
        this.motions.delete(c.id);
        n.actor.bot = c.mode;
        if (!this.botOrigins.has(n.id))
          this.botOrigins.set(
            n.id,
            this.objects.get(n.id)!.getWorldPosition(new THREE.Vector3()),
          );
      }
    }

    if (c.type === "set" && typeof c.id === "string")
      this.applyNodePatch(c.id, c.patch);
    if (c.type === "light" && typeof c.id === "string")
      this.applyLight(c.id, c.patch);
    if (c.type === "flicker" && typeof c.id === "string")
      this.flicker(c.id, c.duration, c.amount);
    if (c.type === "torch")
      this.torchCommand(c.patch, c.enabled);
    if (c.type === "sound" && typeof c.name === "string")
      this.audio.play(c.name, c.volume ?? 1, c.pitch ?? 1);
    if (c.type === "loop" && typeof c.name === "string")
      this.audio.loop(c.name, c.volume ?? 0);
    if (c.type === "volume") this.audio.setVolume(c.value);
    if (
      c.type === "move" &&
      typeof c.id === "string" &&
      c.patch &&
      typeof c.patch === "object"
    )
      this.move(c.id, c.patch, c.seconds);
    if (
      c.type === "ui" &&
      typeof c.id === "string" &&
      this.ui.some((e) => e.id === c.id) &&
      c.patch &&
      typeof c.patch === "object"
    ) {
      const patch: Record<string, unknown> = {};
      if (typeof c.patch.text === "string")
        patch.text = c.patch.text.slice(0, 1200);
      if (typeof c.patch.visible === "boolean") patch.visible = c.patch.visible;
      if (typeof c.patch.value === "number" && Number.isFinite(c.patch.value))
        patch.value = Math.max(0, Math.min(1, c.patch.value));
      for (const key of ["color", "background"])
        if (
          typeof c.patch[key] === "string" &&
          /^#[0-9a-f]{6}([0-9a-f]{2})?$/i.test(c.patch[key])
        )
          patch[key] = c.patch[key];
      this.uiPatches.set(c.id, { ...this.uiPatches.get(c.id), ...patch });
    }
    if (c.type === "voxel" && Array.isArray(c.cell) && c.cell.length === 3)
      this.voxels?.set(c.cell[0], c.cell[1], c.cell[2], c.block);
    if (
      c.type === "voxelReset" &&
      this.voxels &&
      Array.isArray(c.blocks) &&
      c.blocks.length === this.voxels.data.blocks.length &&
      c.blocks.every(
        (v: unknown) =>
          Number.isInteger(v) &&
          (v as number) >= 0 &&
          (v as number) <= this.voxels!.data.palette.length,
      )
    ) {
      this.voxels.data.blocks = [...c.blocks];
      this.voxels.revision++;
      this.voxels.dirty = true;
    }
    if (c.type === "respawn") this.respawn();
    if (c.type === "freeze" && typeof c.value === "boolean")
      this.inputFrozen = c.value;
    if (c.type === "sky" && Number.isFinite(c.elevation))
      this.environment?.set(
        THREE.MathUtils.clamp(c.elevation, -20, 90),
        Number.isFinite(c.azimuth)
          ? THREE.MathUtils.clamp(c.azimuth, -180, 180)
          : undefined,
      );
    if (
      c.type === "spawn" &&
      typeof c.id === "string" &&
      c.id.length < 100 &&
      !this.objects.has(c.id) &&
      this.configs.length < 1800 &&
      c.patch &&
      typeof c.patch === "object"
    ) {
      const kind =
        Object.keys(kindNames).includes(c.patch.kind) &&
        !["terrain", "group"].includes(c.patch.kind)
          ? c.patch.kind
          : "box";
      const human = c.patch.actor && c.patch.actor.humanoid === true;
      const n = makeNode(kind, {
        id: c.id,
        name:
          typeof c.patch.name === "string" ? c.patch.name.slice(0, 100) : c.id,
        physics: "none",
        ...(human ? { actor: { ...actorDefaults, humanoid: true } } : {}),
      });
      const o = human
        ? humanoid(n)
        : new THREE.Mesh(
            advancedGeometry(n) ?? geometry(kind),
            new THREE.MeshStandardMaterial({ color: "#829c75" }),
          );
      o.userData.nodeId = n.id;
      this.root.add(o);
      this.objects.set(n.id, o);
      this.configs.push(n);
      this.applyNodePatch(n.id, c.patch);
    }
    if (
      c.type === "remove" &&
      typeof c.id === "string" &&
      c.id !== this.playerId
    ) {
      const o = this.objects.get(c.id);
      if (o) {
        this.physicalRigs.get(c.id)?.dispose();
        this.physicalRigs.delete(c.id);
        this.disposeLight(c.id);
        this.flickers.delete(c.id);
        this.tweens = this.tweens.filter((t) => t.id !== c.id);
        disposeTree(o);
        this.objects.delete(c.id);
        this.motions.delete(c.id);
        this.turns.delete(c.id);
        this.health.delete(c.id);
        this.botOrigins.delete(c.id);
        const body = this.bodies.get(c.id);
        if (body) this.physics?.removeBody(body);
        this.bodies.delete(c.id);
        this.configs = this.configs.filter((n) => n.id !== c.id);
      }
    }
  }
  refresh() {
    if (this.voxels?.dirty) this.voxels.rebuild();
  }
  clear() {
    this.motions.clear();
    this.turns.clear();
    for (const rig of this.physicalRigs.values()) rig.dispose();
    this.physicalRigs.clear();
    this.health.clear();
    this.botOrigins.clear();
    this.audio.stopAll();
    for (const id of [...this.lights.keys()]) this.disposeLight(id);
    this.flickers.clear();
    this.tweens.length = 0;
    this.torch = {
      ...torchDefaults,
      offset: [...torchDefaults.offset] as [number, number, number],
    };
    this.bots = new BotController();
    this.voxels?.dispose();
    this.voxels = null;
    this.environment?.dispose();
    this.environment = null;
    this.uiPatches.clear();
    this.events = [];
    this.inputFrozen = false;
    for (const child of [...this.root.children]) disposeTree(child);
    this.objects.clear();
    this.bodies.clear();
    this.physics = null;
    this.accumulator = 0;
    this.lastJump = -100;
    this.jumpQueuedUntil = -100;
    this.elapsed = 0;
    this.deaths = 0;
    this.completed = false;
    this.checkpointIndex = -1;
    this.checkpointName = "Início";
    this.lastGround = -100;
    this.lastWarning = -100;
    this.collected = 0;
    this.total = 0;
    this.hidden.clear();
    this.active.clear();
    this.playerId = null;
  }
  dispose() {
    this.clear();
    this.audio.dispose();
    this.root.removeFromParent();
  }
}
export function addLighting(scene: THREE.Scene) {
  const ambient = new THREE.HemisphereLight("#dbf3ef", "#33303c", 2);
  ambient.name = "studio-ambient";
  scene.add(ambient);
  const sun = new THREE.DirectionalLight("#fff0d2", 3);
  sun.name = "studio-sun";
  sun.position.set(5, 12, 6);
  sun.castShadow = true;
  sun.shadow.mapSize.set(2048, 2048);
  sun.shadow.camera.left = -18;
  sun.shadow.camera.right = 18;
  sun.shadow.camera.top = 18;
  sun.shadow.camera.bottom = -18;
  sun.shadow.normalBias = 0.04;
  scene.add(sun);
  scene.add(sun.target);
  const fill = new THREE.DirectionalLight("#91baff", 1.5);
  fill.name = "studio-fill";
  fill.position.set(-8, 5, -7);
  scene.add(fill);
  return () => {
    sun.shadow.dispose();
    ambient.removeFromParent();
    sun.removeFromParent();
    sun.target.removeFromParent();
    fill.removeFromParent();
  };
}
