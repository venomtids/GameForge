import { TerrainBrushController } from "./TerrainBrushController";
import type { Surface } from "../engine/studio-model";
import { configureLighting } from "../engine/Lighting";
import { GameUI } from "../engine/GameUI";
import type { Brush, BrushMode } from "../engine/design";
import {
  forwardRef,
  useEffect,
  useImperativeHandle,
  useRef,
  useState,
} from "react";
import * as THREE from "three";
import { TransformControls } from "three/examples/jsm/controls/TransformControls.js";
import { World, addLighting } from "../engine/World";
import { ScriptHost } from "../engine/Scripts";
import { CameraRig } from "../engine/CameraRig";
import {
  cameraModes,
  type CameraMode,
  type Node3D,
  type Project,
  type SceneData,
  type Vec3,
} from "../engine/model";
export type Tool = "translate" | "rotate" | "scale";
export interface ViewportAPI {
  focus: () => void;
  screenshot: () => string | undefined;
  respawn: () => void;
}
interface Props {
  onSetPaused: (p: boolean) => void;
  onContextAction: (action: string) => void;
  onVoxelEdit: (cell: [number, number, number], type: number) => void;
  voxelBlock: number;
  brushMode: BrushMode;
  brush: Brush;
  onTerrainCommit: (id: string, surface: Surface) => void;
  onDesignHit: (id: string, point: Vec3) => void;
  data: SceneData;
  settings: Project["settings"];
  selected: string | null;
  tool: Tool;
  snap: boolean;
  grid: boolean;
  playing: boolean;
  paused: boolean;
  cameraMode: CameraMode;
  colliders: boolean;
  space: "world" | "local";
  scriptsAllowed: boolean;
  onPause: () => void;
  onSelect: (id: string | null) => void;
  onTransform: (id: string, patch: Partial<Node3D>) => void;
  onLog: (text: string) => void;
  onStats: (fps: number, calls: number) => void;
}
export default forwardRef<ViewportAPI, Props>(function Viewport(props, ref) {
  const mount = useRef<HTMLDivElement>(null),
    current = useRef(props);
  current.current = props;
  const api = useRef<{
    world: World;
    rig: CameraRig;
    transform: TransformControls;
    renderer: THREE.WebGLRenderer;
    grid: THREE.GridHelper;
    box: THREE.BoxHelper;
    scene: THREE.Scene;
    scripts: ScriptHost;
    keys: Set<string>;
  } | null>(null);
  const [context, setContext] = useState<{
    x: number;
    y: number;
    cell?: [number, number, number];
    normal?: number[];
  } | null>(null);
  const [error, setError] = useState(""),
    [hud, setHud] = useState({
      health: 100,
      humanoid: false,
      collected: 0,
      total: 0,
      elapsed: 0,
      deaths: 0,
      checkpoint: "Início",
      completed: false,
    });
  useImperativeHandle(ref, () => ({
    focus: () => {
      const a = api.current;
      if (a)
        a.rig.focus(
          a.world.objects.get(current.current.selected ?? "") ?? a.world.root,
        );
    },
    screenshot: () => {
      const a = api.current;
      if (!a) return;
      a.renderer.render(a.scene, a.rig.camera);
      return a.renderer.domElement.toDataURL("image/png");
    },
    respawn: () => api.current?.world.respawn(),
  }));
  useEffect(() => {
    const host = mount.current!;
    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({
        antialias: true,
        preserveDrawingBuffer: true,
      });
    } catch {
      setError("WebGL indisponível. Ative a aceleração de hardware.");
      return;
    }
    renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1;
    host.appendChild(renderer.domElement);
    const scene = new THREE.Scene();
    const unlight = addLighting(scene);
    const rig = new CameraRig(renderer.domElement);
    rig.onNotice = (t) => current.current.onLog(t);
    const grid = new THREE.GridHelper(140, 140, "#47565b", "#303d43");
    grid.position.y = -1.4;
    scene.add(grid);
    const transform = new TransformControls(rig.camera, renderer.domElement);
    transform.setSize(0.8);
    scene.add(transform.getHelper());
    const world = new World(scene);
    world.onEvent = (t) => current.current.onLog(t);
    const scripts = new ScriptHost(world, (t) => current.current.onLog(t));
    const box = new THREE.BoxHelper(new THREE.Object3D(), "#79dec0");
    box.visible = false;
    scene.add(box);
    const keys = new Set<string>();
    const ui = new GameUI(host, world, (p) => current.current.onSetPaused(p));
    api.current = {
      world,
      rig,
      transform,
      renderer,
      grid,
      box,
      scene,
      scripts,
      keys,
    };
    let dirty = false;
    transform.addEventListener("dragging-changed", (e) => {
      rig.controls.enabled = !e.value;
      if (!e.value && dirty) {
        const o = transform.object;
        if (o)
          current.current.onTransform(o.userData.nodeId, {
            position: o.position.toArray() as Vec3,
            rotation: [o.rotation.x, o.rotation.y, o.rotation.z].map(
              THREE.MathUtils.radToDeg,
            ) as Vec3,
            scale: o.scale
              .toArray()
              .map((v) => Math.max(0.01, Math.min(100, v))) as Vec3,
          });
        dirty = false;
      }
    });
    transform.addEventListener("objectChange", () => {
      dirty = true;
      box.update();
    });
    const resize = new ResizeObserver(() => {
      const w = host.clientWidth,
        h = host.clientHeight;
      if (w && h) {
        renderer.setSize(w, h);
        rig.resize(w / h);
      }
    });
    resize.observe(host);
    const down = (e: KeyboardEvent) => {
      if (
        (e.target as HTMLElement).closest(
          "input,textarea,select,[contenteditable]",
        )
      )
        return;
      if (current.current.playing) {
        if (e.key === "Escape") {
          current.current.onPause();
          rig.release();
          return;
        }
        if (
          /^[a-z0-9]$/i.test(e.key) ||
          [
            "w",
            "a",
            "s",
            "d",
            " ",
            "shift",
            "r",
            "arrowup",
            "arrowdown",
            "arrowleft",
            "arrowright",
          ].includes(e.key.toLowerCase())
        ) {
          e.preventDefault();
          if (!e.repeat || ![" ", "r"].includes(e.key))
            keys.add(e.key.toLowerCase());
          if (!e.repeat) scripts.pressed.add(e.key.toLowerCase());
        }
      }
    };
    const up = (e: KeyboardEvent) => {
        keys.delete(e.key.toLowerCase());
        scripts.released.add(e.key.toLowerCase());
      },
      blur = () => keys.clear();
    const unlock = () => {
      if (
        document.pointerLockElement !== renderer.domElement &&
        current.current.playing &&
        current.current.cameraMode === "first" &&
        !world.inputFrozen
      )
        current.current.onPause();
    };
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    window.addEventListener("blur", blur);
    document.addEventListener("pointerlockchange", unlock);
    let press = [0, 0];
    const pressPosition = new THREE.Vector3();
    const pdown = (e: PointerEvent) => {
      press = [e.clientX, e.clientY];
      pressPosition.copy(rig.camera.position);
      setContext(null);
      if (
        current.current.playing &&
        !current.current.paused &&
        !world.inputFrozen
      ) {
        keys.add("mouse" + e.button);
        scripts.pressed.add("mouse" + e.button);
      }
    };
    const pointerUp = (e: PointerEvent) => {
      keys.delete("mouse" + e.button);
      scripts.released.add("mouse" + e.button);
    };
    const preventContext = (e: Event) => e.preventDefault();
    window.addEventListener("pointerup", pointerUp);
    renderer.domElement.addEventListener("contextmenu", preventContext);
    const pick = (e: PointerEvent) => {
      if (
        e.button === 2 &&
        !current.current.playing &&
        rig.camera.position.distanceTo(pressPosition) < 0.02 &&
        Math.hypot(e.clientX - press[0], e.clientY - press[1]) < 5
      ) {
        const rect = renderer.domElement.getBoundingClientRect(),
          ray = new THREE.Raycaster();
        ray.setFromCamera(
          new THREE.Vector2(
            ((e.clientX - rect.left) / rect.width) * 2 - 1,
            (-(e.clientY - rect.top) / rect.height) * 2 + 1,
          ),
          rig.camera,
        );
        const hit = ray
          .intersectObjects(world.root.children, true)
          .find((h) => h.object.visible);
        if (hit?.object.userData.nodeId)
          current.current.onSelect(hit.object.userData.nodeId);
        const voxel = world.voxels?.hit(ray);
        setContext({
          x: Math.min(e.clientX - rect.left, rect.width - 195),
          y: Math.min(e.clientY - rect.top, rect.height - 220),
          ...(voxel ? { cell: voxel.cell, normal: voxel.normal } : {}),
        });
        return;
      }
      if (
        e.button !== 0 ||
        current.current.playing ||
        transform.dragging ||
        transform.axis ||
        Math.hypot(e.clientX - press[0], e.clientY - press[1]) > 4
      )
        return;
      const rect = renderer.domElement.getBoundingClientRect(),
        ray = new THREE.Raycaster();
      ray.setFromCamera(
        new THREE.Vector2(
          ((e.clientX - rect.left) / rect.width) * 2 - 1,
          (-(e.clientY - rect.top) / rect.height) * 2 + 1,
        ),
        rig.camera,
      );
      const hit = ray.intersectObjects(world.root.children, true).find((h) => {
        let visible = h.object.visible;
        h.object.traverseAncestors((a) => (visible = visible && a.visible));
        return visible;
      });
      if (hit && current.current.brushMode !== "select") {
        const point = hit.point.clone();
        if (
          current.current.data.nodes.find(
            (n) => n.id === hit.object.userData.nodeId,
          )?.surface
        )
          hit.object.worldToLocal(point);
        else hit.object.parent?.worldToLocal(point);
        current.current.onDesignHit(
          hit.object.userData.nodeId,
          point.toArray() as Vec3,
        );
      } else current.current.onSelect(hit?.object.userData.nodeId ?? null);
    };
    renderer.domElement.addEventListener("pointerdown", pdown);
    renderer.domElement.addEventListener("pointerup", pick);
    const terrainBrush = new TerrainBrushController(
      renderer.domElement,
      scene,
      world,
      rig,
      () => current.current,
    );
    const colliderGroup = new THREE.Group();
    scene.add(colliderGroup);
    let colliderSignature = "";
    const helpers: THREE.BoxHelper[] = [];
    const clearHelpers = () => {
      for (const h of helpers) {
        h.geometry.dispose();
        (h.material as THREE.Material).dispose();
        h.removeFromParent();
      }
      helpers.length = 0;
    };
    let frame = 0,
      last = performance.now(),
      sum = 0,
      frames = 0;
    const tick = (now: number) => {
      frame = requestAnimationFrame(tick);
      const dt = Math.min((now - last) / 1000, 0.05);
      last = now;
      const p = current.current;
      rig.configure(p.settings);
      rig.playing = p.playing;
      rig.paused = p.paused || world.inputFrozen;
      if (
        world.inputFrozen &&
        document.pointerLockElement === renderer.domElement
      )
        rig.release();
      scripts.paused = p.paused;
      grid.visible = p.grid && !p.playing;
      grid.position.y = p.data.nodes.some((n) => n.surface) ? -25 : -1.4;
      if (p.playing && !p.paused) {
        const origin = rig.camera.getWorldPosition(new THREE.Vector3()),
          direction = rig.camera.getWorldDirection(new THREE.Vector3());
        const ray = new THREE.Raycaster(origin, direction, 0, 6),
          hit = ray
            .intersectObjects(world.root.children, true)
            .find(
              (h) =>
                h.object.visible &&
                h.object.userData.nodeId &&
                h.object.userData.nodeId !== world.playerId,
            );
        scripts.context = {
          camera: { origin: origin.toArray(), direction: direction.toArray() },
          ray: world.voxels?.hit(ray) ?? null,
          target: hit
            ? { id: hit.object.userData.nodeId, distance: hit.distance }
            : null,
        };
        scripts.update(dt, keys);
        world.update(dt, keys, p.cameraMode === "first" ? rig.yaw : 0);
      }
      terrainBrush.update();
      rig.update(world, dt);
      world.refresh();
      configureLighting(
        scene,
        renderer,
        p.settings,
        p.playing && world.playerId
          ? world.objects
              .get(world.playerId)!
              .getWorldPosition(new THREE.Vector3())
          : rig.controls.target,
      );
      ui.update(p.playing, p.paused);
      if (box.visible) box.update();
      const signature = p.colliders
        ? p.data.id +
          ":" +
          world.root.children[0]?.uuid +
          ":" +
          world.configs.map((n) => n.id + ":" + n.physics).join(",")
        : "";
      if (signature !== colliderSignature) {
        clearHelpers();
        colliderSignature = signature;
        if (p.colliders)
          for (const n of world.configs) {
            if (n.physics === "none" || n.kind === "group") continue;
            const o = world.objects.get(n.id);
            if (o) {
              const helper = new THREE.BoxHelper(
                o,
                n.physics === "dynamic" ? "#efc078" : "#79dfcc",
              );
              helpers.push(helper);
              colliderGroup.add(helper);
            }
          }
      }
      for (const h of helpers) h.update();
      renderer.render(scene, rig.camera);
      sum += dt;
      frames++;
      if (sum >= 0.25) {
        setHud({
          health: world.health.get(world.playerId ?? "") ?? 100,
          humanoid: !!world.configs.find((n) => n.id === world.playerId)?.actor
            .humanoid,
          collected: world.collected,
          total: world.total,
          elapsed: world.elapsed,
          deaths: world.deaths,
          checkpoint: world.checkpointName,
          completed: world.completed,
        });
        current.current.onStats(
          Math.round(frames / sum),
          renderer.info.render.calls,
        );
        sum = 0;
        frames = 0;
      }
    };
    frame = requestAnimationFrame(tick);
    return () => {
      cancelAnimationFrame(frame);
      resize.disconnect();
      window.removeEventListener("keydown", down);
      window.removeEventListener("keyup", up);
      window.removeEventListener("blur", blur);
      document.removeEventListener("pointerlockchange", unlock);
      renderer.domElement.removeEventListener("pointerdown", pdown);
      renderer.domElement.removeEventListener("pointerup", pick);
      scripts.stop();
      ui.dispose();
      window.removeEventListener("pointerup", pointerUp);
      renderer.domElement.removeEventListener("contextmenu", preventContext);
      terrainBrush.dispose();
      transform.dispose();
      rig.dispose();
      clearHelpers();
      world.dispose();
      unlight();
      grid.geometry.dispose();
      (grid.material as THREE.Material).dispose();
      box.geometry.dispose();
      (box.material as THREE.Material).dispose();
      renderer.dispose();
      renderer.forceContextLoss();
      renderer.domElement.remove();
      api.current = null;
    };
  }, []);
  useEffect(() => {
    const a = api.current;
    if (!a) return;
    a.transform.detach();
    a.scripts.stop();
    a.keys.clear();
    a.world.load(props.data, props.settings, props.playing);
    a.rig.yaw = 0;
    a.rig.pitch = -0.12;
    if (props.playing && props.scriptsAllowed) a.scripts.start();
    const o = a.world.objects.get(props.selected ?? "");
    if (o && props.brushMode === "select" && !props.playing) {
      if (!props.data.nodes.find((n) => n.id === props.selected)?.locked)
        a.transform.attach(o);
      a.box.setFromObject(o);
      a.box.visible = true;
    } else a.box.visible = false;
  }, [props.data, props.settings, props.playing, props.scriptsAllowed]);
  useEffect(() => {
    const a = api.current;
    if (!a) return;
    const o = a.world.objects.get(props.selected ?? "");
    a.transform.detach();
    if (o && props.brushMode === "select" && !props.playing) {
      if (!props.data.nodes.find((n) => n.id === props.selected)?.locked)
        a.transform.attach(o);
      a.box.setFromObject(o);
      a.box.visible = true;
    } else a.box.visible = false;
  }, [props.selected, props.playing, props.data, props.brushMode]);
  useEffect(() => {
    const a = api.current;
    if (!a) return;
    a.rig.set(props.cameraMode);
    a.transform.camera = a.rig.camera;
  }, [props.cameraMode]);
  useEffect(() => {
    const a = api.current;
    if (!a) return;
    a.transform.setMode(props.tool);
    a.transform.setSpace(props.space);
    a.transform.setTranslationSnap(props.snap ? 0.5 : null);
    a.transform.setRotationSnap(props.snap ? Math.PI / 12 : null);
    a.transform.setScaleSnap(props.snap ? 0.1 : null);
    a.grid.visible = props.grid;
  }, [props.tool, props.snap, props.grid, props.space]);
  useEffect(() => {
    const a = api.current;
    if (a && (!props.playing || props.paused)) {
      a.rig.release();
      a.keys.clear();
    }
  }, [props.paused, props.playing]);
  return (
    <div
      className={`viewport ${props.playing ? "is-playing" : ""}`}
      ref={mount}
      aria-label="Viewport 3D"
    >
      {error && <div className="webgl-error">{error}</div>}
      {context && !props.playing && (
        <div
          className="viewport-context"
          style={{ left: context.x, top: context.y }}
        >
          <strong>Editar cena</strong>
          {[
            ["add", "Adicionar forma…"],
            ["focus", "Enquadrar seleção"],
            ["duplicate", "Duplicar seleção"],
            ["delete", "Excluir seleção"],
          ].map(([action, label]) => (
            <button
              key={action}
              onClick={() => {
                props.onContextAction(action);
                setContext(null);
              }}
            >
              {label}
            </button>
          ))}
          {context.cell && (
            <>
              <hr />
              <button
                onClick={() => {
                  props.onVoxelEdit(context.cell!, 0);
                  setContext(null);
                }}
              >
                Remover bloco
              </button>
              <button
                onClick={() => {
                  const c = context.cell!,
                    n = context.normal!;
                  props.onVoxelEdit(
                    [c[0] + n[0], c[1] + n[1], c[2] + n[2]],
                    props.voxelBlock,
                  );
                  setContext(null);
                }}
              >
                Colocar bloco ativo
              </button>
            </>
          )}
          <button onClick={() => setContext(null)}>Fechar</button>
        </div>
      )}
      <div className="viewport-label">
        <span className="live-dot" />
        {props.playing
          ? props.paused
            ? "SIMULAÇÃO PAUSADA"
            : "RUNTIME"
          : "EDITOR"}
        <span className="subtle">
          {cameraModes[props.cameraMode]} ·{" "}
          {props.colliders ? "Colisores (AABB)" : "Sombreado"}
        </span>
      </div>
      <div className="axis-widget">
        <span className="axis-y">Y</span>
        <span className="axis-z">Z</span>
        <span className="axis-x">X</span>
        <i />
      </div>
      {props.playing && (
        <>
          <div
            className="runtime-hud"
            style={{ display: props.data.voxel ? "none" : undefined }}
          >
            <strong>
              {hud.completed ? "Percurso concluído!" : props.data.name}
            </strong>
            <span>
              {hud.total
                ? `Cristais ${hud.collected} / ${hud.total}`
                : "Simulação em execução"}{" "}
              · {hud.elapsed.toFixed(1)} s
            </span>
            <small>
              {hud.checkpoint} · {hud.deaths} quedas
            </small>
            {hud.humanoid && (
              <small>
                Vida: {Math.ceil(hud.health)}
                {hud.health <= 0 ? " · R para renascer" : ""}
              </small>
            )}
            {props.paused && <small>Use Pausar para continuar</small>}
          </div>
          {props.cameraMode === "first" && !props.paused && (
            <div className="fps-crosshair" />
          )}
        </>
      )}
      <div className="viewport-help">
        {props.playing
          ? props.cameraMode === "first"
            ? "Clique para capturar o mouse · WASD · Espaço · Shift · R checkpoint · Esc soltar"
            : "WASD · Espaço · Shift · R checkpoint · F8 parar"
          : props.brushMode !== "select"
            ? "Pincel ativo: clique e arraste no terreno · Ctrl+Z desfaz · use Selecionar para voltar"
            : "Direito + WASD: voar · Q/E: altura · Shift: acelerar · Clique direito: ações"}
      </div>
    </div>
  );
});
