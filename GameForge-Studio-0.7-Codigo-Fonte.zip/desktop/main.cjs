const { app, BrowserWindow, ipcMain, dialog, Menu } = require("electron");
const path = require("node:path");
const fs = require("node:fs/promises");
let mainWindow;
const dev = process.argv.includes("--dev");
const trusted = (event) => {
  if (
    !mainWindow ||
    event.sender !== mainWindow.webContents ||
    event.senderFrame !== mainWindow.webContents.mainFrame
  )
    throw new Error("Origem IPC inválida");
};
app.whenReady().then(() => {
  Menu.setApplicationMenu(null);
  mainWindow = new BrowserWindow({
    width: 1480,
    height: 920,
    minWidth: 900,
    minHeight: 650,
    title: "GameForge Studio",
    backgroundColor: "#191e24",
    webPreferences: {
      preload: path.join(__dirname, "preload.cjs"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      webSecurity: true,
    },
  });
  mainWindow.webContents.setWindowOpenHandler(() => ({ action: "deny" }));
  mainWindow.webContents.on("will-navigate", (event) => event.preventDefault());
  mainWindow.webContents.session.setPermissionRequestHandler(
    (_wc, permission, callback) => callback(permission === "pointerLock"),
  );
  mainWindow.webContents.session.webRequest.onHeadersReceived(
    (details, callback) =>
      callback({
        responseHeaders: {
          ...details.responseHeaders,
          "Content-Security-Policy": [
            dev
              ? "default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval'; worker-src blob: data:; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self' ws://127.0.0.1:5173 ws://localhost:5173; object-src 'none'"
              : "default-src 'self'; script-src 'self' 'unsafe-eval'; worker-src blob: data:; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self'; object-src 'none'",
          ],
        },
      }),
  );
  ipcMain.handle("project:open", async (event) => {
    trusted(event);
    // projetos que vieram com a instalação (resources/Projetos)
    const embutidos = path.join(
      app.isPackaged ? process.resourcesPath : __dirname,
      "Projetos",
    );
    const padrao = await fs
      .access(embutidos)
      .then(() => embutidos)
      .catch(() => undefined);
    const result = await dialog.showOpenDialog(mainWindow, {
      defaultPath: padrao,
      filters: [{ name: "Projeto GameForge", extensions: ["json"] }],
      properties: ["openFile"],
    });
    if (result.canceled) return { canceled: true };
    const stat = await fs.stat(result.filePaths[0]);
    if (stat.size > 8_000_000) throw new Error("Limite de projeto: 8 MB.");
    return {
      canceled: false,
      content: await fs.readFile(result.filePaths[0], "utf8"),
    };
  });
  ipcMain.handle("file:save", async (event, content, suggested, kind) => {
    trusted(event);
    if (
      typeof content !== "string" ||
      content.length > 16_000_000 ||
      !["project", "html", "lua", "javascript"].includes(kind) ||
      typeof suggested !== "string"
    )
      throw new Error("Arquivo inválido");
    const result = await dialog.showSaveDialog(mainWindow, {
      defaultPath: path.basename(suggested),
      filters: [
        {
          name:
            kind === "html"
              ? "Jogo HTML"
              : kind === "lua"
                ? "Script Lua"
                : kind === "javascript"
                  ? "Script JavaScript"
                  : "Projeto GameForge",
          extensions: [
            kind === "html"
              ? "html"
              : kind === "lua"
                ? "lua"
                : kind === "javascript"
                  ? "js"
                  : "json",
          ],
        },
      ],
    });
    if (result.canceled || !result.filePath) return { canceled: true };
    await fs.writeFile(result.filePath, content, "utf8");
    return { canceled: false, path: result.filePath };
  });
  if (dev) mainWindow.loadURL("http://127.0.0.1:5173");
  else mainWindow.loadFile(path.join(__dirname, "../dist/index.html"));
});
app.on("window-all-closed", () => app.quit());
