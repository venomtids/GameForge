const { contextBridge, ipcRenderer } = require("electron");
contextBridge.exposeInMainWorld("gameforgeDesktop", {
  platform: process.platform,
  open: () => ipcRenderer.invoke("project:open"),
  save: (content, suggested, kind) =>
    ipcRenderer.invoke("file:save", content, suggested, kind),
});
